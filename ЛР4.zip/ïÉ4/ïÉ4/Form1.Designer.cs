﻿namespace ЛР4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.QueryAllSchoolButton = new System.Windows.Forms.Button();
            this.QueryAllDistrictButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.QueryButton4 = new System.Windows.Forms.Button();
            this.Query4TextBox = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.QueryButton3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.QueryButton2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.QueryButton1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.QueryAllSchoolButton);
            this.panel1.Controls.Add(this.QueryAllDistrictButton);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.QueryButton4);
            this.panel1.Controls.Add(this.Query4TextBox);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.QueryButton3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.QueryButton2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.QueryButton1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1028, 764);
            this.panel1.TabIndex = 0;
            // 
            // QueryAllSchoolButton
            // 
            this.QueryAllSchoolButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryAllSchoolButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryAllSchoolButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryAllSchoolButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryAllSchoolButton.Location = new System.Drawing.Point(285, 698);
            this.QueryAllSchoolButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryAllSchoolButton.Name = "QueryAllSchoolButton";
            this.QueryAllSchoolButton.Size = new System.Drawing.Size(232, 39);
            this.QueryAllSchoolButton.TabIndex = 19;
            this.QueryAllSchoolButton.Text = "Вывести таблицу школы";
            this.QueryAllSchoolButton.UseVisualStyleBackColor = false;
            this.QueryAllSchoolButton.Click += new System.EventHandler(this.QueryAllSchoolButton_Click);
            // 
            // QueryAllDistrictButton
            // 
            this.QueryAllDistrictButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryAllDistrictButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryAllDistrictButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryAllDistrictButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryAllDistrictButton.Location = new System.Drawing.Point(16, 698);
            this.QueryAllDistrictButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryAllDistrictButton.Name = "QueryAllDistrictButton";
            this.QueryAllDistrictButton.Size = new System.Drawing.Size(221, 39);
            this.QueryAllDistrictButton.TabIndex = 18;
            this.QueryAllDistrictButton.Text = "Вывести таблицу районы";
            this.QueryAllDistrictButton.UseVisualStyleBackColor = false;
            this.QueryAllDistrictButton.Click += new System.EventHandler(this.QueryAllDistrictButton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(792, 527);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(212, 29);
            this.label8.TabIndex = 17;
            this.label8.Text = "Изменить номер";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(580, 543);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 29);
            this.label7.TabIndex = 16;
            this.label7.Text = "Школа";
            // 
            // QueryButton4
            // 
            this.QueryButton4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryButton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryButton4.Location = new System.Drawing.Point(672, 668);
            this.QueryButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryButton4.Name = "QueryButton4";
            this.QueryButton4.Size = new System.Drawing.Size(167, 50);
            this.QueryButton4.TabIndex = 15;
            this.QueryButton4.Text = "Запрос";
            this.QueryButton4.UseVisualStyleBackColor = false;
            this.QueryButton4.Click += new System.EventHandler(this.QueryButton4_Click);
            // 
            // Query4TextBox
            // 
            this.Query4TextBox.Location = new System.Drawing.Point(797, 572);
            this.Query4TextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Query4TextBox.Multiline = true;
            this.Query4TextBox.Name = "Query4TextBox";
            this.Query4TextBox.Size = new System.Drawing.Size(215, 43);
            this.Query4TextBox.TabIndex = 14;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(525, 591);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(231, 24);
            this.comboBox3.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(721, 471);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 29);
            this.label6.TabIndex = 12;
            this.label6.Text = "4 запрос";
            // 
            // QueryButton3
            // 
            this.QueryButton3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryButton3.Location = new System.Drawing.Point(664, 391);
            this.QueryButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryButton3.Name = "QueryButton3";
            this.QueryButton3.Size = new System.Drawing.Size(223, 33);
            this.QueryButton3.TabIndex = 11;
            this.QueryButton3.Text = "Запрос";
            this.QueryButton3.UseVisualStyleBackColor = false;
            this.QueryButton3.Click += new System.EventHandler(this.QueryButton3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(721, 327);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "3 запрос";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(565, 208);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "Номер школы";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(543, 257);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(213, 24);
            this.comboBox2.TabIndex = 8;
            // 
            // QueryButton2
            // 
            this.QueryButton2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryButton2.Location = new System.Drawing.Point(872, 257);
            this.QueryButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryButton2.Name = "QueryButton2";
            this.QueryButton2.Size = new System.Drawing.Size(100, 28);
            this.QueryButton2.TabIndex = 7;
            this.QueryButton2.Text = "Запрос";
            this.QueryButton2.UseVisualStyleBackColor = false;
            this.QueryButton2.Click += new System.EventHandler(this.QueryButton2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(721, 146);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "2 запрос";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(596, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Район";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(721, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "1 запрос";
            // 
            // QueryButton1
            // 
            this.QueryButton1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.QueryButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.QueryButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.QueryButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QueryButton1.Location = new System.Drawing.Point(872, 96);
            this.QueryButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QueryButton1.Name = "QueryButton1";
            this.QueryButton1.Size = new System.Drawing.Size(100, 28);
            this.QueryButton1.TabIndex = 3;
            this.QueryButton1.Text = "Запрос";
            this.QueryButton1.UseVisualStyleBackColor = false;
            this.QueryButton1.Click += new System.EventHandler(this.QueryButton1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(543, 96);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(213, 24);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(517, 667);
            this.dataGridView1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 766);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button QueryButton2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button QueryButton1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button QueryButton3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button QueryButton4;
        private System.Windows.Forms.TextBox Query4TextBox;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button QueryAllSchoolButton;
        private System.Windows.Forms.Button QueryAllDistrictButton;
    }
}

