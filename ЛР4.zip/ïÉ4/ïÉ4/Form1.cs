﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace ЛР4
{
    public partial class Form1 : Form
    {
        public Form1()                  //Заполнение combobox
        {
            InitializeComponent();
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand("SELECT district_name FROM district", connection);
                NpgsqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {

                    
                    comboBox1.Items.Add(dataReader.GetString(0));

                }
            }
            a();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void a()
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand("SELECT school_id FROM school", connection);
                NpgsqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    
                    comboBox2.Items.Add(dataReader.GetInt32(0));
                    comboBox3.Items.Add(dataReader.GetInt32(0));

                }
            }
        }

        private void QueryAllDistrictButton_Click(object sender, EventArgs e)               // Выводит все таблицу district
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT * FROM district";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }

        private void QueryAllSchoolButton_Click(object sender, EventArgs e)                         // Выводит всю таблицу school
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT * FROM school";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }

        private void QueryButton1_Click(object sender, EventArgs e)             // 1 запрос
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT district_name,school_phone_number,school_date_placed,school_teacher_count,school_student_count \r\nFROM school\r\nJOIN district ON fk_school_district_id = district_id\r\nWHERE school_date_placed < '2024-05-05' AND district_name = '{comboBox1.Text}'";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void QueryButton2_Click(object sender, EventArgs e)         // 2 запрос
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT * FROM school\r\nWHERE school_id = '{comboBox2.Text}'";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }

        private void QueryButton3_Click(object sender, EventArgs e)         // 3 запрос
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT school_id,(school_student_count / school_teacher_count) AS avg_people\r\nFROM school\r\nORDER BY avg_people ASC;";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }

        private void QueryButton4_Click(object sender, EventArgs e)         // 4 запрос
        {
            NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab4;User Id = postgres;Password=5176565195");
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.Text;
            command.CommandText = $"UPDATE school\r\nSET school_phone_number = '{Query4TextBox.Text}'\r\nWHERE school_id = '{comboBox3.Text}';";
            NpgsqlDataReader dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dataGridView1.DataSource = dataTable;
            }

            command.Dispose();
            connection.Close();
        }
    }
}
