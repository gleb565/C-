﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace ЛР5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int temp;
        public int humid;


        // Получить температуры из 1 цеха
        private void button17_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp, first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                }
            }
            Form2 dialog = new Form2(Convert.ToString(temp), Convert.ToString(humid));
            dialog.ShowDialog();
            Show();

        }

        // Получить температуры из 2 цеха
        private void button18_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp, second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }
            Form2 dialog = new Form2(Convert.ToString(temp), Convert.ToString(humid));
            dialog.ShowDialog();
            Show();

        }

        // Получить температуры из 3 цеха
        private void button19_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp, three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }
            Form2 dialog = new Form2(Convert.ToString(temp), Convert.ToString(humid));
            dialog.ShowDialog();
            Show();

        }

        // Получить температуры из 4 цеха
        private void button20_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp, four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }
            Form2 dialog = new Form2(Convert.ToString(temp), Convert.ToString(humid));
            dialog.ShowDialog();
            Show();

        }

        // Прибавление температуры в 1 цех
        private void button1_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp,first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                    if( temp > 50)
                    {
                        MessageBox.Show("Достигнута максимальная температура!");
                    }
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO first_fabric (first_fabric_temp,first_fabric_date,first_fabric_hum )\r\nVALUES (@first_fabric_temp, @first_fabric_date,@first_fabric_hum);";

                command1.Parameters.AddWithValue("@first_fabric_temp", temp + 1);
                command1.Parameters.AddWithValue("@first_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@first_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }


        // Прибавление влажности в 1 цех
        private void button3_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp,first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO first_fabric (first_fabric_temp,first_fabric_date,first_fabric_hum )\r\nVALUES (@first_fabric_temp, @first_fabric_date,@first_fabric_hum);";

                command1.Parameters.AddWithValue("@first_fabric_temp", temp);
                command1.Parameters.AddWithValue("@first_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@first_fabric_hum", humid + 1);

                command1.ExecuteNonQuery();
            }
        }


        // Вычитание температуры в 1 цех
        private void button2_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp,first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO first_fabric (first_fabric_temp,first_fabric_date,first_fabric_hum )\r\nVALUES (@first_fabric_temp, @first_fabric_date,@first_fabric_hum);";

                command1.Parameters.AddWithValue("@first_fabric_temp", temp - 1);
                command1.Parameters.AddWithValue("@first_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@first_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }

        // Вычитание температуры в 1 цехе
        private void button4_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp,first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO first_fabric (first_fabric_temp,first_fabric_date,first_fabric_hum )\r\nVALUES (@first_fabric_temp, @first_fabric_date,@first_fabric_hum);";

                command1.Parameters.AddWithValue("@first_fabric_temp", temp);
                command1.Parameters.AddWithValue("@first_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@first_fabric_hum", humid - 1);

                command1.ExecuteNonQuery();
            }
        }

        //Прибавление температуры 2 цех
        private void button5_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp,second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO second_fabric (second_fabric_temp,second_fabric_date,second_fabric_hum )\r\nVALUES (@second_fabric_temp, @second_fabric_date,@second_fabric_hum);";

                command1.Parameters.AddWithValue("@second_fabric_temp", temp + 1);
                command1.Parameters.AddWithValue("@second_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@second_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }

        //Вычитание температуры 2 цех
        private void button7_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp,second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO second_fabric (second_fabric_temp,second_fabric_date,second_fabric_hum )\r\nVALUES (@second_fabric_temp, @second_fabric_date,@second_fabric_hum);";

                command1.Parameters.AddWithValue("@second_fabric_temp", temp - 1);
                command1.Parameters.AddWithValue("@second_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@second_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }

        // Прибавление влажности 2 цех
        private void button6_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp,second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO second_fabric (second_fabric_temp,second_fabric_date,second_fabric_hum )\r\nVALUES (@second_fabric_temp, @second_fabric_date,@second_fabric_hum);";

                command1.Parameters.AddWithValue("@second_fabric_temp", temp);
                command1.Parameters.AddWithValue("@second_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@second_fabric_hum", humid + 1);

                command1.ExecuteNonQuery();
            }
        }

        // Вычитание влажности 2 цех
        private void button8_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp,second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO second_fabric (second_fabric_temp,second_fabric_date,second_fabric_hum )\r\nVALUES (@second_fabric_temp, @second_fabric_date,@second_fabric_hum);";

                command1.Parameters.AddWithValue("@second_fabric_temp", temp);
                command1.Parameters.AddWithValue("@second_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@second_fabric_hum", humid - 1);

                command1.ExecuteNonQuery();
            }
        }

        // Прибавление температуры 3 цех
        private void button9_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp,three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO three_fabric (three_fabric_temp,three_fabric_date,three_fabric_hum )\r\nVALUES (@three_fabric_temp, @three_fabric_date,@three_fabric_hum);";

                command1.Parameters.AddWithValue("@three_fabric_temp", temp + 1);
                command1.Parameters.AddWithValue("@three_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@three_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }

        //Вычитание температуры 3 цех
        private void button13_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp,three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO three_fabric (three_fabric_temp,three_fabric_date,three_fabric_hum )\r\nVALUES (@three_fabric_temp, @three_fabric_date,@three_fabric_hum);";

                command1.Parameters.AddWithValue("@three_fabric_temp", temp - 1);
                command1.Parameters.AddWithValue("@three_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@three_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }

        // Прибавление влажность 3 цех
        private void button10_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp,three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO three_fabric (three_fabric_temp,three_fabric_date,three_fabric_hum )\r\nVALUES (@three_fabric_temp, @three_fabric_date,@three_fabric_hum);";

                command1.Parameters.AddWithValue("@three_fabric_temp", temp);
                command1.Parameters.AddWithValue("@three_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@three_fabric_hum", humid + 1);

                command1.ExecuteNonQuery();
            }
        }

        // Вычитание влажности 3 цех
        private void button14_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp,three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO three_fabric (three_fabric_temp,three_fabric_date,three_fabric_hum )\r\nVALUES (@three_fabric_temp, @three_fabric_date,@three_fabric_hum);";

                command1.Parameters.AddWithValue("@three_fabric_temp", temp);
                command1.Parameters.AddWithValue("@three_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@three_fabric_hum", humid - 1);

                command1.ExecuteNonQuery();
            }
        }
        // Прибавление температуры 4 цех
        private void button11_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp,four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO four_fabric (four_fabric_temp,four_fabric_date,four_fabric_hum )\r\nVALUES (@four_fabric_temp, @four_fabric_date,@four_fabric_hum);";

                command1.Parameters.AddWithValue("@four_fabric_temp", temp + 1);
                command1.Parameters.AddWithValue("@four_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@four_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }

        }
        // Вычитание температуры 4 цех
        private void button15_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp,four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO four_fabric (four_fabric_temp,four_fabric_date,four_fabric_hum )\r\nVALUES (@four_fabric_temp, @four_fabric_date,@four_fabric_hum);";

                command1.Parameters.AddWithValue("@four_fabric_temp", temp - 1);
                command1.Parameters.AddWithValue("@four_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@four_fabric_hum", humid);

                command1.ExecuteNonQuery();
            }
        }
        // Прибавленеи влажности 4 цех
        private void button12_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp,four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO four_fabric (four_fabric_temp,four_fabric_date,four_fabric_hum )\r\nVALUES (@four_fabric_temp, @four_fabric_date,@four_fabric_hum);";

                command1.Parameters.AddWithValue("@four_fabric_temp", temp);
                command1.Parameters.AddWithValue("@four_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@four_fabric_hum", humid - 1);

                command1.ExecuteNonQuery();
            }
        }
        //Вычитание влажности 4 цех
        private void button16_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp,four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }

            using (NpgsqlConnection connection1 = new NpgsqlConnection($"Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection1.Open();

                NpgsqlCommand command1 = new NpgsqlCommand();
                command1.Connection = connection1;
                command1.CommandType = CommandType.Text;
                command1.CommandText = $"INSERT INTO four_fabric (four_fabric_temp,four_fabric_date,four_fabric_hum )\r\nVALUES (@four_fabric_temp, @four_fabric_date,@four_fabric_hum);";

                command1.Parameters.AddWithValue("@four_fabric_temp", temp);
                command1.Parameters.AddWithValue("@four_fabric_date", DateTime.Now.Date);
                command1.Parameters.AddWithValue("@four_fabric_hum", humid - 1);

                command1.ExecuteNonQuery();
            }
        }
// Вывод в txt файл 1 цех
        private void button21_Click(object sender, EventArgs e)
        {

            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT first_fabric_temp,first_fabric_hum\r\nFROM first_fabric\r\nORDER BY first_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["first_fabric_temp"]);
                    humid = Convert.ToInt32(reader["first_fabric_hum"]);
                }
            }

            string filePath = @"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\File.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Записываем значения переменных temp и humid в файл
                writer.WriteLine($"1 цех: ");
                writer.WriteLine($"Temperature: {temp}");
                writer.WriteLine($"Humidity: {humid}");
            }
        }
// Вывод в txt файл 2 цех
        private void button22_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT second_fabric_temp,second_fabric_hum\r\nFROM second_fabric\r\nORDER BY second_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["second_fabric_temp"]);
                    humid = Convert.ToInt32(reader["second_fabric_hum"]);
                }
            }

            string filePath = @"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\File.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Записываем значения переменных temp и humid в файл
                writer.WriteLine($"2 цех: ");
                writer.WriteLine($"Temperature: {temp}");
                writer.WriteLine($"Humidity: {humid}");
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT three_fabric_temp,three_fabric_hum\r\nFROM three_fabric\r\nORDER BY three_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["three_fabric_temp"]);
                    humid = Convert.ToInt32(reader["three_fabric_hum"]);
                }
            }

            string filePath = @"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\File.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Записываем значения переменных temp и humid в файл
                writer.WriteLine($"3 цех: ");
                writer.WriteLine($"Temperature: {temp}");
                writer.WriteLine($"Humidity: {humid}");
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=lab5;User Id=postgres;Password=5176565195"))
            {
                connection.Open();

                NpgsqlCommand command = new NpgsqlCommand();
                command.Connection = connection;
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT four_fabric_temp,four_fabric_hum\r\nFROM four_fabric\r\nORDER BY four_fabric_id DESC\r\nLIMIT 1;";
                NpgsqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    temp = Convert.ToInt32(reader["four_fabric_temp"]);
                    humid = Convert.ToInt32(reader["four_fabric_hum"]);
                }
            }

            string filePath = @"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\File.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Записываем значения переменных temp и humid в файл
                writer.WriteLine($"4 цех: ");
                writer.WriteLine($"Temperature: {temp}");
                writer.WriteLine($"Humidity: {humid}");
            }
        }
    }
        }

