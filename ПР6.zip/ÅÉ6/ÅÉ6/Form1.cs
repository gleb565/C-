﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Application.EnableVisualStyles();
        }


        private void DrawFiguresFromFile(string fileName)
        {
            // Создание нового изображения
            Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics graphics = Graphics.FromImage(bitmap);

            // Очистка изображения
            graphics.Clear(Color.White);

            // Чтение данных из файла и отрисовка фигур
            using (StreamReader reader = new StreamReader(fileName))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(' ');       // Разбираем строку на части через пробел
                    if (parts[0] == "TEXT")
                    {
                        int x = int.Parse(parts[1]);
                        int y = int.Parse(parts[2]);
                        string text = string.Join(" ", parts, 3, parts.Length - 3);
                        graphics.DrawString(text, new Font("Arial", 12), Brushes.Black, x, y);
                    }
                    else if (parts[0] == "CIRCLE")
                    {
                        int x = int.Parse(parts[1]);
                        int y = int.Parse(parts[2]);
                        int radius = int.Parse(parts[3]);
                        graphics.DrawEllipse(Pens.Black, x - radius, y - radius, radius * 2, radius * 2);
                    }
                }
            }

            // Отображение изображения в PictureBox
            pictureBox1.Image = bitmap;
        }


        // Считывание данных и отрисовка
        private void StartButton_Click(object sender, EventArgs e)
        {
            string filePath = "D:\\Лабораторные работы\\Программирование и алгоритмизация на языках высокого уровня\\WinForms\\ПР6\\draw.txt";

            if (File.Exists(filePath))
            {
                // Чтение данных из файла и отрисовка фигур
                DrawFiguresFromFile(filePath);
            }
            else
            {
                MessageBox.Show("Файл не найден!");
            }
        }

        // Сохранение файла
        private void SaveButton_Click(object sender, EventArgs e)
        {

            // Открытие диалога сохранения файла
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Изображение PNG (*.png)|*.png";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Сохранение изображения в файл
                pictureBox1.Image.Save(saveFileDialog.FileName, System.Drawing.Imaging.ImageFormat.Png);
            }
        }
    }
}

