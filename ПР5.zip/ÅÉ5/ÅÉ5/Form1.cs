﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ПР5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            string filePath = @"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\ПР5\MyFile.csv";

            // Создаем файл, если его не существует
            if (!File.Exists(filePath))
            {
                using (File.Create(filePath)) { }
            }

            using (StreamWriter sw = new StreamWriter(filePath, true, Encoding.UTF8))
            {
                // Записываем значения из TextBox в файл, разделяя запятыми
                sw.WriteLine($"{AddTextBox.Text}");
            }
        }

        private void ReadButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\ПР5\MyFile.csv"))
            {
                DataTable dt = new DataTable();

                // Чтение данных из файла и заполнение DataTable
                string[] lines = File.ReadAllLines(@"D:\Лабораторные работы\Программирование и алгоритмизация на языках высокого уровня\WinForms\ПР5\MyFile.csv");
                if (lines.Length > 0)
                {
                    // Создание столбцов на основе заголовков из первой строки файла
                    string[] headers = lines[0].Split(';');
                    foreach (string header in headers)
                    {
                        dt.Columns.Add(header);
                    }

                    // Заполнение данными
                    for (int i = 1; i < lines.Length; i++)
                    {
                        string[] dataRow = lines[i].Split(',');
                        if (dataRow.Length == headers.Length)
                        {
                            dt.Rows.Add(dataRow);
                        }
                        else
                        {
                            MessageBox.Show($"Строка {i + 1} в файле CSV имеет неправильное количество значений. Пропускаем эту строку.");
                        }
                    }

                    // Привязка DataTable к dataGridView1
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Файл пуст.");
                }
            }
            else
            {
                MessageBox.Show("Файл не найден.");
            }
        }
    }
}
